
from TestLoad.UnitTest.LoadUnitTestBase import LoadUnitTestBase

class LoadTestBaseFactory(object):

	def get_unittest(self):
		return LoadUnitTestBase()


