from TestLoad.LoadTestBaseFactory import LoadTestBaseFactory

class LoadUnitTestBase(LoadTestBaseFactory):
	pass
