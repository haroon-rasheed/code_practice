#! /usr/bin/python

#import sys,os.path

#sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from ELTTestBaseFactory import ELTTestBaseFactory

et = ELTTestBaseFactory.get_test_factory('LOAD')
