
class ExtractTestBaseFactory:
	pass

