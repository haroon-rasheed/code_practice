from ExtractTestBaseFactory import ExtractTestBaseFactory

class ExtractUnitTestBase(ExtractTestBaseFactory):
	pass
