from LoadTestBaseFactory import LoadTestBaseFactory

class LoadRegnTestBase(LoadTestBaseFactory):
	pass
