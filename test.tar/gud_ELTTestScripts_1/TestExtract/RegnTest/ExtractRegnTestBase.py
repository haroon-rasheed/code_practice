from ExtractTestBaseFactory import ExtractTestBaseFactory

class ExtractRegnTestBas(ExtractTestBaseFactory):
	pass
